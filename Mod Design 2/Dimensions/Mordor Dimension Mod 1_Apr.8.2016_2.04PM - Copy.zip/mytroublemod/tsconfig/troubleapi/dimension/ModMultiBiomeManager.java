package mytroublemod.tsconfig.troubleapi.dimension;

import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManager;
import net.minecraft.world.biome.WorldChunkManagerHell;

public class ModMultiBiomeManager extends WorldChunkManager {

	public ModMultiBiomeManager(long par1, WorldType par3WorldType) {
		super(par1, par3WorldType);
	}

}
