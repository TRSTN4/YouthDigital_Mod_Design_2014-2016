package mytroublemod.tsconfig.troubleapi.dimension;

import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManagerHell;

public class ModSingleBiomeManager extends WorldChunkManagerHell {

	public ModSingleBiomeManager(BiomeGenBase par1BiomeGenBase,
			float par2, float par3) {
		super(par1BiomeGenBase, par2, par3);
	}

}
