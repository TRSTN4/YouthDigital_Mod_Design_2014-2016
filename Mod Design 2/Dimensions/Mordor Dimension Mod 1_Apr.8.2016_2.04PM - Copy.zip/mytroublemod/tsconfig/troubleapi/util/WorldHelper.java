package mytroublemod.tsconfig.troubleapi.util;

import mytroublemod.tsconfig.troubleapi.dimension.ModWorldProvider;

public class WorldHelper {

	public static void setCloudHeight(ModWorldProvider provider, float height) {
		provider.setCloudHeight(height);
	}

}
